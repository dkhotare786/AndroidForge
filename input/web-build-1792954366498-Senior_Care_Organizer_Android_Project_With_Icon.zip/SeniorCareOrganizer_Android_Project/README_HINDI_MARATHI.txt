Senior Care Organizer — Android Studio Project (Prototype v0.1)

महत्त्वाची गोष्ट:
ही APK फाइल नाही; हा APK तयार करण्यासाठी Android Studio project आहे. या वातावरणात Android SDK / build tools उपलब्ध नसल्यामुळे येथे थेट APK compile करता आले नाही.

APK तयार करण्याची पद्धत:
1. संगणकावर Android Studio install करा.
2. हा ZIP extract करा.
3. Android Studio → Open → extract केलेला SeniorCareOrganizer_Android_Project folder निवडा.
4. Gradle sync पूर्ण होऊ द्या. गरज पडल्यास Android SDK Platform 35 आणि Android Gradle Plugin आवश्यक फाइल्स install होऊ द्या.
5. Build → Build Bundle(s) / APK(s) → Build APK(s) निवडा.
6. APK साधारणपणे app/build/outputs/apk/debug/app-debug.apk येथे मिळेल.
7. APK आपल्या Android फोनवर पाठवून install करा. फोनमध्ये आवश्यक असल्यास त्या स्रोतासाठी Install unknown apps परवानगी द्यावी लागेल.

या प्रोटोटाइपमध्ये:
- मराठी, हिंदी, इंग्रजी UI
- औषध नोंदी, वेळा आणि ॲप उघडे असताना रिमाइंडर तपासणी
- डॉक्टर भेटी
- आपत्कालीन संपर्क आणि डायलर उघडणारा Call पर्याय
- स्थानिक ब्राउझर/WebView storage व JSON backup/import

मर्यादा:
- पार्श्वभूमीतील विश्वसनीय अलार्म / Android notification scheduling यात अजून नाही.
- क्लाउड सिंक, खाते, encrypted database किंवा remote backup नाही.
- हा वैद्यकीय सल्ला किंवा आपत्कालीन सेवेचा पर्याय नाही.
- व्यावसायिक प्रकाशनापूर्वी गोपनीयता, सुरक्षा, accessibility आणि विविध Android डिव्हाइसवर चाचणी आवश्यक आहे.
