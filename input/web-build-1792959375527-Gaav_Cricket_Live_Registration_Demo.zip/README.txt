गाव क्रिकेट LIVE — Admin & Organizer Demo

उघडणे:
1. ZIP Extract करा.
2. index.html Chrome मध्ये उघडा.

डेमो वैशिष्ट्ये:
- Admin control concept / organizer panel
- आयोजक स्पर्धा प्रकाशित करतो
- 1 ते 10+ बक्षिसे: rank, trophy/cup/medal आणि रोख रक्कम
- संघ प्रवेश फी व UPI reference demo form
- PhonePe/Google Pay/UPI साठी प्रत्यक्ष payment gateway अजून जोडलेला नाही
- निकाल/विजेता संघ आणि फोटो अपलोड डेमो
- WhatsApp share
- Live stream link field

महत्त्वाच्या मर्यादा:
हा HTML prototype आहे; सर्व डेटा याच फोन/ब्राउझरमध्ये राहतो.
यात प्रत्यक्ष admin authentication/permissions नाहीत, खरे पेमेंट घेतले जात नाही,
फोटो cloud वर साठवले जात नाहीत, इतर फोनवर live sync/push notifications नाहीत.
Production app साठी backend/database, secure login/roles, image storage,
payment gateway, notification service आणि moderation/audit logs आवश्यक आहेत.


Payment shortcut update:
- Home screen has a Pay Now shortcut that opens the payment section.
- Payment panel has PhonePe, Google Pay and Other UPI choices.
- If an organizer UPI ID is supplied, the demo tries a standard UPI intent with the listed entry fee.
- This is not a payment gateway; actual payment confirmation, settlement, receipts, refunds and anti-fraud verification require a production integration.


Registration features added:
- Cricket Team Registration: team name, village, captain, phone, WhatsApp, player count, optional logo, email and roster.
- Cricket Organizer Registration: organizer/club name, village, contact, phone, WhatsApp, email, experience and frequency.
- Demo records appear on the same browser only.
- Production needs secure backend/database, OTP verification, admin approval, access roles and privacy safeguards.
