GRAM CRICKET DYNASTY (GCD) — Android WebView demo project

App display name: GRAM CRICKET DYNASTY
Brand abbreviation: GCD
Tagline suggestion: Every Village. Every Match. One Dynasty.

Project contents: Android Gradle project with WebView-based demo UI, local demo live score controls, and an advertiser/admin demo panel for image/banner ads and approvals.

IMPORTANT LIMITATIONS:
- This ZIP is a source project, NOT an APK. It must be built using Android Studio or a compatible Android build service.
- Data is stored locally on the device only; no online database or real multi-device live score sync.
- No secure admin login or server-side role protection.
- No real payment processing or payment verification.
- The current teams/fixtures areas are demo placeholders, not complete tournament management.
- Popup ad display is not fully wired to auto-trigger.
- This is an independent cricket project and is not affiliated with BCCI or any official cricket board.

Build with Android Studio / compatible service by importing this project folder or uploading this ZIP if the service accepts full Android Gradle projects.
