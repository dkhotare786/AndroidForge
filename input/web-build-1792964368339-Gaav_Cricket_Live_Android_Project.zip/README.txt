गाव क्रिकेट LIVE Android project (WebView demo)

हे Android Studio/AndroidForge साठी प्रोजेक्ट सोर्स आहे; तयार APK नाही.
या ZIP मध्ये settings.gradle आणि app/build.gradle आहेत, त्यामुळे HTML ZIP थेट APK builder ला देण्याऐवजी हा प्रोजेक्ट अपलोड करा.

टीप:
- हा स्थानिक डेमो आहे.
- Supabase/online realtime, authentication, payment gateway किंवा सुरक्षित आयोजक भूमिका जोडलेल्या नाहीत.
- APK build करण्यासाठी Android SDK/Gradle उपलब्ध असलेल्या बिल्डरची गरज आहे.
